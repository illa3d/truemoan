Discord - https://discord.com/channels/620113492208517120/1312401584910631054/1355675724932972634

https://i.gyazo.com/430cb42f82bb096d243fb0b55e884ff7.mp4
https://i.gyazo.com/6b15db28a20f7d149a722f5b15909e7d.mp4
https://i.gyazo.com/7eed2a42a282d1096550ebb70a6a5721.mp4

Added new buttons "AutoBJ" and "Auto Thrust!" for organic animations. 

written on top of "FreemodeHG version 0.3"

Enjoy