-- TrueMoan v0.8 by illa3d
-----------------------------------------------
-- MAIN CONFIG FILE, MODIFY TO YOOUR LIKING! --
-----------------------------------------------

-- Body Edit
EditSafe = true		 -- default value on scene change
BreastSafeMin = -0.8 -- some characters fall apart below this value and game crashes

-- Body Edit Increments
BodyStepA = 0.3		-- nipples
BodyStepB = 0.1		-- hip, waist, ass, breast, muscle
BodyStepC = 0.05	-- neck, forearm, upperarm, calf, thigh, penis-length, penis-size
BodyStepD = 0.02	-- body

-- Sex/Moan Tier config
WetSex = true		-- default value on scene change
Moaning = true		-- default value on scene change
WetnessStep = 200	-- Umm. Try lol.

-- Cum moan frequency
MoanCumEyeTime = 1	-- seconds
MoanCumLipsTime = 3	-- seconds
MoanCumBodyTime = 5	-- seconds

-- Sex Moan Tresholds (speed 0-2)
ClimaxTreshold = 1.3
OrgasmTreshold = 0.9
FasterTreshold = 0.6
FastTreshold = 0.3
NormalTreshold = 0.1

-- Menu labels
MenuBack = "| BACK"
MenuClose = "| CLOSE"

-- Ambience
AllowAmbience = true
AmbienceVolume = 0.4	-- 0 to 1

-- Music tracks displayed in Options/Music
MusicTracks = {
	"01_Dreamy_Whisper",
	"02_Moon-blind",
	"03_OpenMeBabe",
	"04_What_an_Easy_Good-bye",
	"05_Somtimes",
	"06_Love_in_Fareast",
	"07_Tender_Passion",
	"08_Orbit",
	"09_Dancing_Queen",
	"10_Memories_of_Childhood",
	"11_Raggae_Fever",
	"12_Why",
	"13_Comma",
	"14_NoWar",
	"15_Special_Light",
	"16_Enjoy_Yaslef",
	"17_Lyve_Live",
	"18_Aquabelle",
	"19_1st_Mission",
	"20_Time_to_Groove",
	"21_Love_is_Bubble",
	"22_Flower_Bearing",
	"23_Secret_Garden_Before",
	"24_X-ray",
	"25_CallousCall",
	"26_Order_Circle",
	"27_This_is_My_Stage",
	"28_Wait_4_U",
	"29_Welcome_to_Radux_World",
	"30_Journey_to_You",
}