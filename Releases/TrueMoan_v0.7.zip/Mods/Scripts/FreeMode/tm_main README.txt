---------------------------------------------------------------------------------------------------------
--                                               TRUE MOAN                                             --
---------------------------------------------------------------------------------------------------------

REALISTIC MOANING
- 950+ unique moans (thx Chiyoru, Spicy Sounds Bundle)
- 6 moan tiers: Slow, Normal, Fast, Faster, Orgasm, Climax
- Organic speed dependant moaning
- Fluid reaction moaning
- Togglable in talk menu/options/moaning and game options/fluid reactions

FEATURES
- Slick Menu UX - Complete menu re-edit
- Body Edit
	- Presets (Skinny, Slim, Normal, Curvy, Obese)
	- Reduce/enlarge beyond slider values for all body parts
	- Apply chosen values to multiple actors quickly
- Sex controls
	- Natural / Auto BJ / Auto Thrust
	- Thrusting (Presets, Slower and Faster)
	- Cum frequency
	- Wetness (Presets, Less and More)
- Animation and poses
- Character Reset - stand up, stop all animations, normal face

INTEGRATED MODS
- @heartgrenade: FreeModeHG v0.3.zip - https://discord.com/channels/620113492208517120/1312401584910631054/1349491994510233661
- @faunap: FreeModeHG v0.3 - faunap_edit_0.2.zip - https://discord.com/channels/620113492208517120/1312401584910631054/1355724274224205984
- @masterchief_87971: Natural AutoBJ AutoThrust - https://discord.com/channels/620113492208517120/1312401584910631054/1355675724932972634
- @callmedrjones6911: Face expression looping - https://discord.com/channels/620113492208517120/1312401584910631054/1349562400105431090

Thanks everyone for the effort, pretty slick mods! <3

---------------------------------------------------------------------------------------------------------
-- INSTALLATION
---------------------------------------------------------------------------------------------------------

REQUIREMENTS
- True Facials v0.59
- No mod dependancies

COMPATIBILITY
- *NOT* compatible with other mods that do FreeMode folder scripting (ie: nf123 Voice Mod)
- if mod is installed with other mods, they will not work until TrueMoan is deleted

HOW TO INSTALL
- (if you have mods) backup/rename folder: "Mods/Scripts/FreeMode"
- backup/rename "Mods/Scripts/FreeMode/Image.png"
- extract TrueMoan_v#.#.zip to TrueFacials game folder (should be no overwrites)

HOW TO UNINSTALL (folder: Mods/Scripts/FreeMode)
- restore backed up "Image.png" (if you backed it up before install)
- delete all "tm_*.lua" and "tm_*.txt" files
- delete all "Voice/tm_*.mp3" audio files

---------------------------------------------------------------------------------------------------------
-- CHANGELOG
---------------------------------------------------------------------------------------------------------

[ v0.7 ]
- WetSex option
- Split the menu files for easier editing / updating
- Extracted Close & Back labels to tm_menu.lua

[ v0.6 ]
- BodyEdit presets (skinny, slim, normal, curvy, obese)
- BodyEdit Safe edit option (breasts below -0.8 crash the game on some characters)
- Renamed mod to "TrueMoan" from "FreemodeHG v0.3 - faunap_edit_0.2 - GenSound01 - Auto ThrustBJ - illa3d_edit"
- Split files for easier updating
- Renamed files so it doesn't overwrite other mods
- "freemode_main.lua" is not required (even if it exists in folder), "tm_main_illa3d.lua" overrides functions
  happens automagically - same function in multiple files, alphabetically last one used!

[ v0.5 ]
- Menu UX improvements
- New moaning tier: Climax
- Sex controls: More presets, better Faster/Slower controls

[ v0.4 ]
- TrueMoan system: Slow, Normal, Fast, Faster, Orgasm
- Menu UX - improvements

[ v0.3 ]
- Menu UX - completely reorganized the menu and unified the style
- Body Edit - reduce/enlarge beyond slider values for all body parts

[ v0.2 ]
- Menu UX - completely reorganized the menu and unified the style
- Main menu fixed item list - dynamic ones appear under "Hey, Lara", "Sex" and "Anim.."
- Character Reset - setting stand up, normal face, stop all animations

[ v0.1 ]
- Menu UX - improvements
- Moaning - Reduced tresholds for slow/normal/fast moans
- Sex speed - Presets, Slower and Faster
- Body Edit - reduce/enlarge beyond slider values for: Body, Breasts, Ass, Penis size, Penis length (revamped "Illegal character customization") 
- Wetness - Presets, Less and More
- Visible values while editing options

[ v0.0 ] Combined multiple mods from FreeModeHG thread to one archive
- @heartgrenade: FreeModeHG v0.3.zip - https://discord.com/channels/620113492208517120/1312401584910631054/1349491994510233661
- @faunap: FreeModeHG v0.3 - faunap_edit_0.2.zip - https://discord.com/channels/620113492208517120/1312401584910631054/1355724274224205984
- @masterchief_87971: Natural AutoBJ AutoThrust - https://discord.com/channels/620113492208517120/1312401584910631054/1355675724932972634
- @callmedrjones6911: Face expression looping - https://discord.com/channels/620113492208517120/1312401584910631054/1349562400105431090