I was really getting bothered with how starting a new position always resets the humping speed as I prefer slower speeds, so I modified the current HC script to include some extra buttons. You can adjust the values yourself to any speed you like by changing "human.Penis.Interaction.m_autoSpeed"

Third time I try to post this, still had some bugfixing to do. This is my little contribution to, and celebration of, the community here. Thanks to @sfin for the info. Thanks to HG for... HG. And thx to Henry and the team.

