﻿function Anim_Name(actorA, actorB, fadeTime, overridePos, overrideRot)
actorA = Human(actorA, "lunafreya", "primrose office")
actorB = Human(actorB, "black male", "leon s kennedy")

local point = MapPoint("map_store", Pos(-2.441, -0.071, 6.834), Rot(0, 0, 0), overridePos, overrideRot, function()
	Skybox("illa_arizona", 0, 0).Light("LightFan", 0, 0, 5E-06).Light("FX_TX_E15A_GSbrodyscreen_Emissive", 0, 0, 9E-08).Light("LightMachineCatching01", 0, 0, 5E-07).Light("LightLamp01", 0.07549974, 0.9474996, 2.1385).Light("LampDesk", 0.05, 0.15, 2E-06).Light("FX_TX_E1_1A_ScreenSaver_Bckground_Emissive", 0, 0, 2E-07).Light("TX_Tech_VendingSoda01_Emissive", 0.6, 0.09, 5E-07)
	actorA.Material("Lunafreya_Torso", 0.997, -0.255, 0, 0).Material("Lunafreya_Torso_Nipples", 0.9385002, -0.5624998, 0, 0).Material("Body", 0.997, -0.255, 0, 0).Material("Head", 0.997, -0.255, 0, 0).Material("HairTied1", 0.8664997, -0.6599994, 0, 0).Material("Lingerie", 0.7315001, 0.0674997, -0.5087482, -1).Material("OfficeLady_Shirt", 0.1800001, -0.9525008, 0, 0)
	actorB.Material("ShirtsPart", 0, 0, -0.465, -0.0075)
end)
actorA.PlaceAt(Pos(-0.006, 0.017, -0.256), Rot(0, 203.901, 0), point)
actorB.PlaceAt(Pos(0.007, -0.016, 0.257), Rot(0, 184.778, 0), point)

actorA.Body("Body size", -0.07896727, "Breasts size", -0.8, "Ass size", -1, "Hips size", -0.2, "Thigh size", -0.09999999, "Calf size", -0.1, "Upper arms size", -0.09999999, "Forearms size", -0.1, "Fluid speed", 0.09)
actorB.Body("Penis size", 0.03987241, "Penis length", -0.1795014, "Nipples size", 0.3180024, "Fluid speed", 0.09, "Fluid amount", 1.136753)

actorA.Customize("Panties", 1, "Garter", 1, "Vest", 6, "Tie", 1, "Skirt", 1, "Heels", 1)
actorB.Customize("Boots", 1, "CottnBelt", 1, "Pants", 1, "Jacket", 1)

PoseCam(Pos(1.865, 0.937, -0.039), Pos(0.047, 1.033, -0.14), point)

NewClip().Layer(MotionLayer.PlayerPose).Fade(fadeTime).Actors(actorA).WrapMode(MotionWrap.Loop).Data(
	Hips(WPos(-0.006, 0.991, 0.15)),
	HipsRot(34.325, -52.875, -24.7),
	Head(-0.037, 0.726, 0.687),
	HeadRot(331.686, 246.894, 22.451),
	EyeL(WorldPos(-1.808, 1.956, 6.103)),
	EyeR(WorldPos(-1.808, 1.956, 6.103)),
	FootL(WSurface(TPos(-0.391, 0.857, 0.173), -0.04, -0.999, 0.002)),
	FootR(WSurface(TPos(0.041, 0.072, -0.051), 0, -1)),
	HandL(WSurface(WPos(-0.436, 1.221, 0.416), -0.214, 0.526, 0.823), Wrist(HPoint(0, -0.3, 0.7, 90), 0, 35)),
	ThumbL(20, 20, 20, 0, 0, TargetActor.World, "Null"),
	IndexL(20, 20, 20, 0, 0, TargetActor.World, "Null"),
	MidL(20, 20, 20, 0, 0, TargetActor.World, "Null"),
	RingL(20, 20, 20, 0, 0, TargetActor.World, "Null"),
	PinkyL(20, 20, 20, 0, 0, TargetActor.World, "Null"),
	HandR(WSurface(WPos(0.15, 1.488, 0.578), -0.252, 0, 0.968), Wrist(HPoint(0, -0.3, 0.7, 90), 0, 35)),
	ThumbR(-17.764, 37.195, 37.195, -20, 0, TargetActor.Null, "Null"),
	IndexR(20, 20, 20, 0, 0, TargetActor.World, "Null"),
	MidR(20, 20, 20, 0, 0, TargetActor.World, "Null"),
	RingR(20, 20, 20, 0, 0, TargetActor.World, "Null"),
	PinkyR(20, 20, 20, 0, 0, TargetActor.World, "Null"),
	ElbowL(),
	ElbowR(-0.651),
	WristL(0.973, -15.155, 1.567),
	WristR(26.78, 72.629, -102.949),
	KneeL(0.262),
	KneeR(0.417),
	AnkleL(14.175, 0, 8.866),
	AnkleR(41.916, 0, 40),
	SpineRot(-10.425),
	Mouth(-0.235, -0.04, 0, -0.412, 0.117, -0.915, -0.915, -0.25, -0.38, -0.818, -0.818),
	Brows(1, 1, -0.272, -0.272),
	EyelidL(-0.35),
	EyelidR(-0.35),
	Cheeks(1, 0.809)
)
NewClip().Layer(MotionLayer.PlayerPose).Fade(fadeTime).Actors(actorB, actorA).WrapMode(MotionWrap.Loop).Data(
	Penis(TargetActor.A, "Vagina", TargetActor.Null, "", 0, 0, 0, 0, true, 0.649, 0.1, 1.027, 0.788, false, 0.25, 0.65, 1.25, 1.353, 1.2),
	Hips(WPos(0, 1.096, 0.298)),
	HipsRot(-33.575, 0, -0.525),
	Head(0, 0.995, 0.102),
	HeadRot(30.28, 1.281, 10.755),
	EyeL(CameraPos()),
	EyeR(CameraPos()),
	FootL(WSurface(TPos(-0.103, 0, 0.23), 0, -1)),
	FootR(WSurface(TPos(0.214, 0.067, 0.288), 0, -1)),
	HandL(HPos(-0.283, -0.906, 0.096), Wrist(HPoint(0, -0.3, 0.7, 90), 0, 35)),
	ThumbL(20, 20, 20, 0, 0, TargetActor.Null, "Null"),
	IndexL(20, 20, 20, 0, 0, TargetActor.Null, "Null"),
	MidL(20, 20, 20, 0, 0, TargetActor.Null, "Null"),
	RingL(20, 20, 20, 0, 0, TargetActor.Null, "Null"),
	PinkyL(20, 20, 20, 0, 0, TargetActor.Null, "Null"),
	HandR(BoneMesh(TargetActor.A, "Bone_Hips", 0.032, -0.529, 0.03), Wrist(HPoint(0, -0.3, 0.7, 90), 0, 35)),
	ThumbR(20, 20, 20, 0, 0, TargetActor.A, "Bone_Hips"),
	IndexR(20, 20, 20, 0, 0, TargetActor.A, "Bone_Hips"),
	MidR(20, 20, 20, 0, 0, TargetActor.A, "Bone_Hips"),
	RingR(20, 20, 20, 0, 0, TargetActor.A, "Bone_Hips"),
	PinkyR(20, 20, 20, 0, 0, TargetActor.A, "Bone_Hips"),
	ElbowL(0.226),
	KneeL(-0.074),
	KneeR(0.13),
	AnkleL(19.201),
	AnkleR(26.887),
	SpineRot(-16.575),
	Mouth(0, 0, 0, 0.384, 0.384, 0, 0, 0.833, 0.833, 0.438, 0.438)
)
end