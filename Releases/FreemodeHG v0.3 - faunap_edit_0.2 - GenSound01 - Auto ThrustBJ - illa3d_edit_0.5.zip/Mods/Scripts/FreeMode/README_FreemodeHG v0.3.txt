FreemodeHG v0.3 is here! This will replace default freemode. To install, go into Mods/Scripts, make a backup of the freemode folder, then delete it and unizip the mod.

Release notes:
- Menus have been redone and are now more organized.
- There is now voice modding support. More details below
- The animation system was reworked. Now you can set the speed of custom loops (Credits to sfin for the tech). More details below.
- You can toggle UI visibility (Credits to sfin for the tech)
- Button to start/stop handjobs will showup if relevant.
- Asking a girl to remove all clothes wont also make her grow a penis anymore.
- [customization] You can now shrink the characters by repeatedly pressing the button.
- [customization] You can suppress fluids coming out from the vagina. it is recommended to do that at lower body sizes.
- [customization] You can reset the foreskin position
- [customization] Super fast autosex should be faster now.