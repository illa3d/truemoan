Made a generic soundpack! Also made a small change to the script so it'll pick between "Slow", "Normal", and "Fast" moans.
https://www.mediafire.com/file/85gn35cga4y2g2n/nobodyforever123_Generic_Soundpack_01.zip/file

Modification instructions are in the zip file. A premodified freemode_main.lua (v0.3) is included in the zip file if you wish to use that instead.
In the Talk Menu, a new "Voice" button is added, in it you can adjust the Slow Threshold and Normal Threshold so the desired moan variation plays for your scene.

All 580 mp3 files has to be placed in the Mods\Scripts\Freemode\Voice folder (subfolders do not work!).
Voice sourced from Chiyoru found in the Spicy Sounds Bundle.

If you don't wish to modify the original script, I also provided just the normal moans in the "gen_moan" format.
Let me know if there's any problems! 

---

The sound changes depending on penis velocity. Currently it's set so:
Velocity under 0.6 = Slow moans
Velocity 0.6 to 0.95 = Normal moans
Velocity over 0.95 = Fast moans
The threshold changes the 0.6 and 0.95 value. (Currently shown as an offset. For the next release I'll just display the actual values)

---

Script modification:

--Add in variables
	slowvoiceadjust = 0
	normalvoiceadjust = 0

--Add in label TalkMenu
	+ "Voice" [gold]
		+ "Increase slow threshold " .. slowvoiceadjust
			slowvoiceadjust = slowvoiceadjust + 0.01
			Return(1)
		+ "Decrease slow threshold"
			slowvoiceadjust = slowvoiceadjust - 0.01
			Return(1)
		+ "Increase normal threshold " .. normalvoiceadjust
			normalvoiceadjust = normalvoiceadjust + 0.01
			Return(1)
		+ "Decrease normal threshold"
			normalvoiceadjust = normalvoiceadjust - 0.01
			Return(1)
		+ "Back"
			Return(2)

--Replace function OnPenetration
function OnPenetration(girl, holeName, inVelocity, outVelocity, penetrator)
	local key = "PenetrationMoan_" .. girl.Name .. holeName
	local lastMoanTime = Timer(key)
	local slowthreshold = 0.6 + slowvoiceadjust
	local normalthreshold = 0.95 + normalvoiceadjust

	if inVelocity > 0.03 and inVelocity < slowthreshold and lastMoanTime > 0.8 then 
		girl.SayCustom(girl.Name.."_moan_slow")
		girl.SayCustom("gen_moan_slow")
		ResetTimer(key)
	elseif inVelocity >= slowthreshold and inVelocity < normalthreshold and lastMoanTime > 0.4 then 
		girl.SayCustom(girl.Name.."_moan_normal")
		girl.SayCustom("gen_moan_normal")
		ResetTimer(key)
	elseif inVelocity >= normalthreshold and lastMoanTime > 0.005 then 
		girl.SayCustom(girl.Name.."_moan_fast")
		girl.SayCustom("gen_moan_fast")
		ResetTimer(key)
	end
end